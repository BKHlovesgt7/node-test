
.onAttach <- function(libname, pkgname) {
   packageStartupMessage(
      '\n\n\n\n\n*********************\n\n\n\n  Navigating qeML:\n
      Type vignette("Quick_Start") for a quick overview!\n
      Type vignette("Function_List") for a categorized function list\n
      Type vignette("ML_Overview") for an introduction to machine learning')
}

